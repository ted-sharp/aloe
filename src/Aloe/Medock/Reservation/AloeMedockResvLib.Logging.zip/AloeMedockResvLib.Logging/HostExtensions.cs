﻿using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Serilog.Sinks.SystemConsole.Themes;
using Serilog;
using Serilog.Core;
using Serilog.Events;
using Aloe.Medock.Reservation.AloeMedockResvLib.Logging.Serilog;

namespace Aloe.Medock.Reservation.AloeMedockResvLib.Logging.Serilog;

public static class HostExtensions
{

    /// <summary>
    /// Serilog を有効にします。
    /// </summary>
    public static IHostApplicationBuilder AddSerilog(this IHostApplicationBuilder builder)
    {
        return builder.AddSerilog(null);
    }

    /// <summary>
    /// Serilog を有効にします。追加の Sink を指定できます。
    /// </summary>
    public static IHostApplicationBuilder AddSerilog(this IHostApplicationBuilder builder, params ILogEventSink[] additionalSinks)
    {
        var innerLogger = CreateOutputLogger(additionalSinks);

        Serilog.Log.Logger = HostExtensions.CreateBufferingLogger(innerLogger);

        builder.Logging.ClearProviders();
        builder.Logging.AddSerilog();

        return builder;
    }

    /// <summary>
    /// バッファリングを行うための中間ロガーです。
    /// </summary>
    private static Serilog.Core.Logger CreateBufferingLogger(Serilog.ILogger innerLogger)
    {
        var customSink = new BufferingSink(innerLogger, new BufferingSinkOptions
        {
            BatchSize = 1000,
            FlushInterval = TimeSpan.FromSeconds(5),
            EagerlyEmitFirstEvent = true,
        });

        return new LoggerConfiguration()
            .MinimumLevel.Verbose()
            //.MinimumLevel.ControlledBy(logLevelSwitch)
            .Enrich.WithProcessId()
            .Enrich.WithThreadId()
            .Enrich.WithMachineName()
            .WriteTo.Sink(customSink)
            .CreateLogger();
    }

    private static Serilog.Core.Logger CreateOutputLogger(params ILogEventSink[] additionalSinks)
    {
        var template = "APP [{Timestamp:HH:mm:ss} {Level:u3}] {Message:lj} (TID: {ThreadId}){NewLine}{Exception}";

        var serilogConfiguration = new Serilog.LoggerConfiguration()
            .MinimumLevel.Verbose()
            //.MinimumLevel.ControlledBy(logLevelSwitch)
            .WriteTo.Debug(
                restrictedToMinimumLevel: LogEventLevel.Debug,
                outputTemplate: template)
            .WriteTo.Console(
                theme: AnsiConsoleTheme.Literate,
                outputTemplate: template)
            .WriteTo.File(
                path: "logs/log-.txt",
                rollingInterval: RollingInterval.Day,
                retainedFileCountLimit: 31,
                outputTemplate: template,
                shared: true);

        // TODO: クリティカルのときは Email を送りたい

        // TODO: 必要であればDBにも出力できるようにする？

        foreach (var sink in additionalSinks ?? [])
        {
            serilogConfiguration.WriteTo.Sink(sink);
        }

        return serilogConfiguration.CreateLogger();
    }

}
